package proyecto.models;

/**
 *
 * @author tans_
 */
public class Administrador {
    private int id;
    private String nombre;
    private String apPat;
    private String apMat;
    private int tel;
    private String user;
    private String pass;

    public Administrador() {
    }

    public Administrador(String nombre, String apPat, String apMat, int tel, String user, String pass) {
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.tel = tel;
        this.user = user;
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}