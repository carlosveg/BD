package proyecto.models;

/**
 *
 * @author tans_
 */
public class Descripcion {
    private int id;
    private int IdTipo;
    private String historia;
    private int edad;
    private String color;
    private char sexo;
    private char vacuna;

    public Descripcion() {
    }

    public Descripcion(int IdTipo, String historia, int edad, String color, char sexo, char vacuna) {
        this.IdTipo = IdTipo;
        this.historia = historia;
        this.edad = edad;
        this.color = color;
        this.sexo = sexo;
        this.vacuna = vacuna;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdTipo() {
        return IdTipo;
    }

    public void setIdTipo(int IdTipo) {
        this.IdTipo = IdTipo;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public char getVacuna() {
        return vacuna;
    }

    public void setVacuna(char vacuna) {
        this.vacuna = vacuna;
    }
    
    
}