package proyecto.models;

/**
 *
 * @author tans_
 */
public class Descripcion {
    private int id;
    private int IdTipo;
    private String historia;
    private int edad;
    private String color;
    private String sexo;
    private String vacuna;
    private String urlImagen;

    public Descripcion() {
    }

    public Descripcion(int IdTipo, String historia, int edad, String color, String sexo, String vacuna, String urlImagen) {
        this.IdTipo = IdTipo;
        this.historia = historia;
        this.edad = edad;
        this.color = color;
        this.sexo = sexo;
        this.vacuna = vacuna;
        this.urlImagen = urlImagen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdTipo() {
        return IdTipo;
    }

    public void setIdTipo(int IdTipo) {
        this.IdTipo = IdTipo;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getVacuna() {
        return vacuna;
    }

    public void setVacuna(String vacuna) {
        this.vacuna = vacuna;
    }
    
    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }
}