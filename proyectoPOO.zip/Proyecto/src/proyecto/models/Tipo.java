package proyecto.models;

/**
 *
 * @author tans_
 */
public class Tipo {
    private int id;
    private char tipo;
    private String raza;

    public Tipo() {
    }

    public Tipo(char tipo, String raza) {
        this.tipo = tipo;
        this.raza = raza;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
}
