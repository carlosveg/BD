package proyecto.models;

/**
 *
 * @author tans_
 */
public class Tipo {
    private int id;
    private String tipo;
    private String raza;

    public Tipo() {
    }

    public Tipo(String tipo, String raza) {
        this.tipo = tipo;
        this.raza = raza;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
}
