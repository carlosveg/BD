package proyecto.models;

/**
 *
 * @author tans_
 */
public class Rescatista {
    private int id;
    private String nombre;
    private String apPat;
    private String apMat;
    private int tel;

    public Rescatista() {
    }

    public Rescatista(String nombre, String apPat, String apMat, int tel) {
        this.nombre = nombre;
        this.apPat = apPat;
        this.apMat = apMat;
        this.tel = tel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }
    
    
}