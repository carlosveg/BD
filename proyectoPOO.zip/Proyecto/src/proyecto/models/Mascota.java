package proyecto.models;

/**
 *
 * @author tans_
 */
public class Mascota {
    private int id;
    private int idResc;
    private int idDesc;
    private String nombre;

    public Mascota() {
    }

    public Mascota(int idResc, int idDesc, String nombre) {
        this.idResc = idResc;
        this.idDesc = idDesc;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdResc() {
        return idResc;
    }

    public void setIdResc(int idResc) {
        this.idResc = idResc;
    }

    public int getIdDesc() {
        return idDesc;
    }

    public void setIdDesc(int idDesc) {
        this.idDesc = idDesc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
