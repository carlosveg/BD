package proyecto.controllers;

import java.io.IOException;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

/**
 *
 * @author tans_
 */
public class UtilitiesViews {
    
    public void cambiarVentana(String nameFXML, String titulo, ActionEvent e) throws IOException
    {
        ocultarVentanaActual(e);
        
        Stage stage = new Stage();        
        Parent root = FXMLLoader.load(getClass().getResource("/proyecto/views/"+ nameFXML +".fxml"));
        Scene scene = new Scene(root);
        
        //stage.initModality(Modality.APPLICATION_MODAL);
        //stage.initStyle(StageStyle.UTILITY);
        stage.setTitle(titulo);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    /* Recibimos ActionEvent del boton para poder cerrar su ventana */
    public void ocultarVentanaActual(ActionEvent e)
    {
        Node source = (Node) e.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }
    
    public static boolean confirmMensaje(String titulo, String mensaje)
    {
        boolean respuesta = false;
        Alert alerta = new Alert(AlertType.CONFIRMATION);
        
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        
        Optional<ButtonType> result = alerta.showAndWait();
        
        if(result.get() == ButtonType.OK)
            respuesta = true;
        
        return respuesta;
    }
    
    public static void infoMensaje(String titulo, String mensaje)
    {
        Alert alerta = new Alert(AlertType.INFORMATION);
        
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}