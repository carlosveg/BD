package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;


/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewOptionsAdminController implements Initializable {

    @FXML
    void administrarMascotas(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewMascota", "Administrando Mascotas", e);
    }
    
    @FXML
    void administrarRescatistas(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewRescatista", "Administrando Rescatistas", e);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
