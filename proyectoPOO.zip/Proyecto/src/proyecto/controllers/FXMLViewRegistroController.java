package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import proyecto.models.Administrador;
import proyecto.models.Rescatista;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewRegistroController implements Initializable {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApPat;
    @FXML
    private TextField txtApMat;
    @FXML
    private TextField txtTel;
    @FXML
    private TextField txtUser;
    @FXML
    private TextField txtPass;
    @FXML
    private Button btnRegistrar;
    @FXML 
    private Button btnVolver;
    @FXML
    private Button btnLimpiar;
    @FXML
    private RadioButton rbAdmin;
    @FXML
    private RadioButton rbResc;
    
    private boolean todoOK;
    
    @FXML
    void volverLogin(ActionEvent e) throws IOException
    {
        UtilitiesViews cambio = new UtilitiesViews();
        cambio.cambiarVentana("FXMLViewMain", "Login", e);
    }
    
    @FXML
    void inicializarRadioButton()
    {
        ToggleGroup grupo = new ToggleGroup();
        
        this.rbAdmin.setToggleGroup(grupo);
        this.rbResc.setToggleGroup(grupo);
        this.rbAdmin.setSelected(true);
        this.rbResc.setSelected(false);
    }
    
    @FXML
    void limpiarForm(ActionEvent e)
    {
        this.txtNombre.setText("");
        this.txtApPat.setText("");
        this.txtApMat.setText("");
        this.txtTel.setText("");
        this.txtUser.setText("");
        this.txtPass.setText("");
        inicializarRadioButton();
        this.txtUser.setEditable(true);
        this.txtPass.setEditable(true);
    }
    
    /* Si se va a registrar un rescatista se deshabilitarán las cajas de texto "usuario" y "contraseña" */
    @FXML
    void rescSelected(ActionEvent e)
    {
        this.txtUser.setEditable(false);
        this.txtPass.setEditable(false);
        this.txtUser.setText("");
        this.txtPass.setText("");
    }
    /* Si se va a registrar un administrador se activan las cajas de texto "usuario" y "contraseña" */
    @FXML
    void adminSelected(ActionEvent e)
    {
        this.txtUser.setEditable(true);
        this.txtPass.setEditable(true);
    }
    
    boolean validarTel(String tel)
    {
        boolean telOK = Pattern.matches("[0-9]{8}", tel);
        //boolean telOK = Pattern.matches("\\d{8}", tel);
        
        return telOK;
    }
    
    boolean camposVacios()
    {
        this.todoOK = false;
        
        /* Si se registra a un rescatista solo validamos 4 campos */
        if(this.txtNombre.getText().isEmpty() || this.txtApPat.getText().isEmpty() || this.txtApMat.getText().isEmpty() || this.txtTel.getText().isEmpty())
            this.todoOK = true;
        /* Si se registra a un admin tenemos que validar los 4 campos anteriores y además los 2 extras pertenecientes al admin */
        if(this.rbAdmin.isSelected())
        {
            if(this.txtUser.getText().isEmpty() || this.txtPass.getText().isEmpty())
                this.todoOK = true;
        }
        
        return this.todoOK;
    }
    
    @FXML
    void registro(ActionEvent e)
    {
        /* 
        Para el campo del teléfono solo se aceptan 8 dígitos
        Lo cambiaré en la BD para que acepte un número chido de 10 dígitos
        */
        
        if(!camposVacios() && validarTel(this.txtTel.getText()))
        {
            ManejoDB mn = new ManejoDB();
            
            if(this.rbAdmin.isSelected())
            {
                if(mn.agregarAdmin(new Administrador(this.txtNombre.getText(), this.txtApPat.getText(), this.txtApMat.getText(), Integer.parseInt(this.txtTel.getText()), this.txtUser.getText(), this.txtPass.getText())))
                    UtilitiesViews.infoMensaje("ERROR", "Algo salió mal :c");
                else
                    UtilitiesViews.infoMensaje("EXITO", "Administrador registrado con éxito");
            }
            else if(this.rbResc.isSelected())
            {
                if(mn.agregarResc(new Rescatista(this.txtNombre.getText(), this.txtApPat.getText(), this.txtApMat.getText(), Integer.parseInt(this.txtTel.getText()))))
                    UtilitiesViews.infoMensaje("ERROR", "Algo salió mal :c");
                else
                    UtilitiesViews.infoMensaje("EXITO", "Rescatista registrado con éxito");
            }
        }
        else
            UtilitiesViews.infoMensaje("ERROR", "Hay campos vacíos \nO el formato del teléfono no es el correcto");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializarRadioButton();
    }    
    
}
