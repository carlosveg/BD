package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewMascotaController implements Initializable {

    @FXML
    void volverOpciones(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewOptionsAdmin", "Bienvenido", e);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
