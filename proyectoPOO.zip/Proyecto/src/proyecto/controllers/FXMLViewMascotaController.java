package proyecto.controllers;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import proyecto.models.Mascota;
import proyecto.models.Descripcion;
import proyecto.models.Rescatista;
import proyecto.models.Tipo;

public class FXMLViewMascotaController {

    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private Button btnVolver;
    @FXML
    private TextField txtIdMascota;
    @FXML
    private TextField txtIdResc;
    @FXML
    private TextField txtIdDesc;
    @FXML
    private TextField txtNombreM;
    @FXML
    private TextField txtRaza;
    @FXML
    private Button btnEjecutar;
    @FXML
    private ComboBox<String> cmbAcciones;
    @FXML
    private TextField txtEdad;
    @FXML
    private TextField txtColor;
    @FXML
    private TextField txtVacuna;
    @FXML
    private TextField txtSexo;
    @FXML
    private TextArea txaHist;
    @FXML
    private TextField txtNombreR;
    @FXML
    private TextField txtApPat;
    @FXML
    private TextField txtApMat;
    @FXML
    private TextField txtTel;
    @FXML
    private TextField txtIdTipo;
    @FXML
    private TextField txtTipo;
    @FXML
    private ImageView imgMascota;
    @FXML
    private TextField txtUrl;
    
    
    private boolean consultasOK;
    
    @FXML
    void volverOpciones(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewOptionsAdmin", "Bienvenido", e);
    }

    /* Desactivamos campos ya que en busqueda y eliminación solo se ocupa el id de la mascota*/
    void camposNoEditables()
    {
        this.txtIdMascota.setEditable(true);
        this.txtIdResc.setEditable(false);
        this.txtIdDesc.setEditable(false);
        this.txtIdTipo.setEditable(false);
        this.txtNombreM.setEditable(false);
        this.txtEdad.setEditable(false);
        this.txtTipo.setEditable(false);
        this.txtRaza.setEditable(false);
        this.txtSexo.setEditable(false);
        this.txtVacuna.setEditable(false);
        this.txtColor.setEditable(false);
        this.txaHist.setEditable(false);
        this.txtNombreR.setEditable(false);
        this.txtApPat.setEditable(false);
        this.txtApMat.setEditable(false);
        this.txtTel.setEditable(false);
    }
    
    /* Activamos campos de datos y desactivamos los id ya que no son modificable */
    void camposEditables()
    {
        this.txtIdMascota.setEditable(false);
        /*
        habilitamos el id del rescatista
        dado que puede cambiarse el rescatista asociado a la mascota
        */
        this.txtIdResc.setEditable(true);
        this.txtIdDesc.setEditable(false);
        this.txtIdTipo.setEditable(false);
        this.txtNombreM.setEditable(true);
        this.txtEdad.setEditable(true);
        this.txtTipo.setEditable(true);
        this.txtRaza.setEditable(true);
        this.txtSexo.setEditable(true);
        this.txtVacuna.setEditable(true);
        this.txtColor.setEditable(true);
        this.txaHist.setEditable(true);
        //En la administración de mascotas no podemos editar los datos del rescatista
        this.txtNombreR.setEditable(false);
        this.txtApPat.setEditable(false);
        this.txtApMat.setEditable(false);
        this.txtTel.setEditable(false);
    }
    
    void limpiarCajasTexto()
    {
        this.txtIdMascota.setText("");
        this.txtIdResc.setText("");
        this.txtIdDesc.setText("");
        this.txtIdTipo.setText("");
        this.txtNombreM.setText("");
        this.txtEdad.setText("");
        this.txtTipo.setText("");
        this.txtRaza.setText("");
        this.txtSexo.setText("");
        this.txtVacuna.setText("");
        this.txtColor.setText("");
        this.txaHist.setText("");
        this.txtNombreR.setText("");
        this.txtApPat.setText("");
        this.txtApMat.setText("");
        this.txtTel.setText("");
    }
    
    void imageDefault()
    {
        Image img = new Image("proyecto/views/aseets/image/default.png");
        imgMascota.setPreserveRatio(false);
        imgMascota.setImage(img);
    }
    
    @FXML
    void isFieldActive(ActionEvent event) {
        String accion = this.cmbAcciones.getValue();
        
        if(accion.equalsIgnoreCase("Buscar"))
        {
            camposNoEditables();
            limpiarCajasTexto();
            imageDefault();
        }
        else if(accion.equalsIgnoreCase("Modificar"))
            camposEditables();
        else if(accion.equalsIgnoreCase("Registrar"))
        {
            camposEditables();
            limpiarCajasTexto();
            imageDefault();
        }
        else if(accion.equalsIgnoreCase("Eliminar"))
        {
            camposNoEditables();
            limpiarCajasTexto();
            imageDefault();
        }
    }
    
    void buscarMascota() throws IOException
    {
        ManejoDB mn = new ManejoDB();
        Mascota mascota = mn.getMascota(Integer.parseInt(this.txtIdMascota.getText()));
        Descripcion desc;
        Rescatista resc;
        Tipo tipo;
        
        if(mascota != null)
        {
            desc = mn.getDescripcion(mascota.getIdDesc());
            resc = mn.getRescatista(mascota.getIdResc());
            
            if(desc != null && resc != null)
            {
                tipo = mn.getTipo(desc.getIdTipo());
                
                if(tipo != null)
                {
                    /*
                    como ya verificamos que todas las consultas devolvieron un resultado
                    procedemos a llenar los textField del form con los datos correspondientes
                    */
                    this.txtIdResc.setText(""+ mascota.getIdResc());
                    this.txtIdDesc.setText(""+ mascota.getIdDesc());
                    this.txtIdTipo.setText(""+ desc.getIdTipo());
                    this.txtNombreM.setText(mascota.getNombre());
                    this.txtEdad.setText(""+ desc.getEdad());
                    this.txtTipo.setText(tipo.getTipo());
                    this.txtRaza.setText(tipo.getRaza());
                    this.txtSexo.setText(desc.getSexo());
                    this.txtVacuna.setText(desc.getVacuna());
                    this.txtColor.setText(desc.getColor());
                    this.txaHist.setText(desc.getHistoria());
                    this.txtNombreR.setText(resc.getNombre());
                    this.txtApPat.setText(resc.getApPat());
                    this.txtApMat.setText(resc.getApMat());
                    this.txtTel.setText(""+ resc.getTel());
                    this.txtUrl.setText(desc.getUrlImagen());
                    
                    //colocamos la imagen correspondiente a la mascota en el image view en el imageview
                    Image img = new Image(this.txtUrl.getText());
                    imgMascota.setPreserveRatio(false);
                    imgMascota.setImage(img);
                }
            }
        }
        else
            UtilitiesViews.infoMensaje("Sin resultados", "No existe mascota con ID = "+ this.txtIdMascota.getText());
    }
    
    boolean modificarMascota()
    {
        this.consultasOK = false;
        
        ManejoDB mn = new ManejoDB();
        Mascota mascota = new Mascota(Integer.parseInt(this.txtIdResc.getText()), Integer.parseInt(this.txtIdDesc.getText()), this.txtNombreM.getText());
        Descripcion desc = new Descripcion(Integer.parseInt(this.txtIdTipo.getText()), this.txaHist.getText(), Integer.parseInt(this.txtEdad.getText()), this.txtColor.getText(), this.txtSexo.getText(), this.txtVacuna.getText(), this.txtUrl.getText());
        Tipo tipo = new Tipo(this.txtTipo.getText(), this.txtRaza.getText());
        
        mascota.setId(Integer.parseInt(this.txtIdMascota.getText()));
        desc.setId(Integer.parseInt(this.txtIdDesc.getText()));
        tipo.setId(Integer.parseInt(this.txtIdTipo.getText()));
        
        if(!mn.modificarMascota(mascota) && !mn.modificarDescripcion(desc) && !mn.modificarTipo(tipo))
        {
            System.out.println("Se cumplieron todas las modificaciones");
            this.consultasOK = true;
        }
        
        return this.consultasOK;
    }
    
    /*
    Para registrar a la mascota, primero debemos hacer un registro de forma ascendente, es decir,
    dado que Mascota depende de su Descripción y a su vez, Descripción depende de Tipo, entonces
    primero registramos el tipo de mascota, después la descripción de la mascota y al final registramos
    a la mascota por completo.
    */
    boolean registrarMascota() //no está validado si se duplica un registro
    {
        this.consultasOK = false;
        
        boolean tipoOk, descOk, mascOk;
        int lastIdTipo, lastIdDesc;
        ManejoDB mn = new ManejoDB();
        Descripcion desc;
        Mascota mascota;
        Tipo tipo = new Tipo(this.txtTipo.getText(), this.txtRaza.getText());
        
        tipoOk = mn.agregarTipo(tipo);
        
        lastIdTipo = mn.getLastId("IDTIPO", "tipo");
        
        if(lastIdTipo == 0)
            this.consultasOK = false;
        else
        {
            desc = new Descripcion(lastIdTipo, this.txaHist.getText(), Integer.parseInt(this.txtEdad.getText()), this.txtColor.getText(), this.txtSexo.getText(), this.txtVacuna.getText(), this.txtUrl.getText());
            
            descOk = mn.agregarDescripcion(desc);
            
            lastIdDesc = mn.getLastId("IDDESCRIPCION", "descripcion");
            
            if(lastIdDesc == 0)
                this.consultasOK = false;
            else
            {
                mascota = new Mascota(Integer.parseInt(this.txtIdResc.getText()), lastIdDesc, this.txtNombreM.getText());
                
                mascOk = mn.agregarMascota(mascota);
                
                if(!tipoOk && !descOk && !mascOk)
                {
                    System.out.println("Se agregaron todos los datos");
                    this.consultasOK = true;
                }
            }
        }        

        return this.consultasOK;
    }
    
    boolean eliminarMascota()
    {
        ManejoDB mn = new ManejoDB();
        
        return !mn.eliminar("mascota", Integer.parseInt(this.txtIdMascota.getText()));
    }

    @FXML
    void realizarAccion(ActionEvent event) throws IOException {
        String accion = this.cmbAcciones.getValue();
        
        System.out.println("Se ha seleccionado: "+ accion.toUpperCase());
        
        if(accion.equalsIgnoreCase("Buscar"))
            buscarMascota();
        else if(accion.equalsIgnoreCase("Modificar"))
        {
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea modificar mascota?"))
            {
                if(modificarMascota())
                    UtilitiesViews.infoMensaje("EXITO", "Mascota modificada con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Registrar"))
        {
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea registrar mascota?"))
            {
                if(registrarMascota())
                    UtilitiesViews.infoMensaje("EXITO", "Mascota registrada con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Eliminar"))
        {
            buscarMascota();
            
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea eliminar mascota?"))
            {
                if(eliminarMascota())
                    UtilitiesViews.infoMensaje("EXITO", "Mascota eliminada con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
    }
    
    void copiarArchivo(File file) throws IOException
    {
        String dest = System.getProperty("user.dir")+ "/src/proyecto/views/aseets/image/"+ file.getName();
        Path destino = Paths.get(dest);
        String orig = file.getPath();
        Path origen = Paths.get(orig);
        Files.copy(origen, destino, REPLACE_EXISTING);
        
        System.out.println("Archivo copiado a: "+ destino);
        this.txtUrl.setText("file:/"+ dest);
    }
    
    void setImagen() throws MalformedURLException, IOException
    {
        FileChooser fc = new FileChooser();
        
        fc.setTitle("Agregar imagen");
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        
        File file = fc.showOpenDialog(null);
        
        if(file != null)
        {
            String imageURL = file.toURI().toURL().toString();
            System.out.println("URL: "+ imageURL);
            
            Image img = new Image(imageURL);
            imgMascota.setPreserveRatio(false);
            imgMascota.setImage(img);
            
            copiarArchivo(file);
            
            //aquí agregamos un método para guardar la imagen en la BD
        }
        else
        {
            UtilitiesViews.infoMensaje("ERROR", "Seleccione una imagen con un formato válido\njpg, png, jpeg");
        }
    }
    
    @FXML
    void cargarImagen(ActionEvent e) throws IOException
    {
        setImagen();
    }

    void inicializarForm()
    {
        //inicializamos el comboBox
        this.cmbAcciones.getItems().addAll("Buscar", "Modificar", "Registrar", "Eliminar");
        //textArea hará un salto de línea cuando se llegue al borde derecho.
        this.txaHist.setWrapText(true);
    }
    
    @FXML
    void initialize() {
        inicializarForm();
    }
}