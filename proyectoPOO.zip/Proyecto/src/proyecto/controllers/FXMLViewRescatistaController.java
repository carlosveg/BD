package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import proyecto.models.Rescatista;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewRescatistaController implements Initializable {

    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApPat;
    @FXML
    private TextField txtApMat;
    @FXML
    private TextField txtTel;
    @FXML
    private ComboBox<String> cmbAcciones;
    
    @FXML
    void volverOpciones(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewOptionsAdmin", "Bienvenido", e);
    }
    
    /* Desactivamos campos ya que en busqueda y eliminación solo se ocupa el id */
    void camposNoEditables()
    {
        this.txtId.setEditable(true);
        this.txtNombre.setEditable(false);
        this.txtApPat.setEditable(false);
        this.txtApMat.setEditable(false);
        this.txtTel.setEditable(false);
    }
    
    /* Activamos campos de datos y desactivamos el id ya que ese no es modificable */
    void camposEditables()
    {
        this.txtId.setEditable(false);
        this.txtNombre.setEditable(true);
        this.txtApPat.setEditable(true);
        this.txtApMat.setEditable(true);
        this.txtTel.setEditable(true);
    }
    
    void limpiarCajasTexto()
    {
        this.txtId.setText("");
        this.txtNombre.setText("");
        this.txtApPat.setText("");
        this.txtApMat.setText("");
        this.txtTel.setText("");
    }
    
    void buscarRescatista()
    {
        ManejoDB mn = new ManejoDB();
        Rescatista searchResc = mn.getRescatista(Integer.parseInt(this.txtId.getText()));
        
        if(searchResc != null)
        {
            this.txtNombre.setText(searchResc.getNombre());
            this.txtApPat.setText(searchResc.getApPat());
            this.txtApMat.setText(searchResc.getApMat());
            this.txtTel.setText(String.valueOf(searchResc.getTel()));
        }
        else
            UtilitiesViews.infoMensaje("Sin resultados", "No existe el rescatista con ID = "+ this.txtId.getText());
    }
    
    boolean modificarRescatista()
    {
        ManejoDB mn = new ManejoDB();
        Rescatista newResc = new Rescatista(this.txtNombre.getText(), this.txtApPat.getText(), this.txtApMat.getText(), Integer.parseInt(this.txtTel.getText()));
        
        newResc.setId(Integer.parseInt(this.txtId.getText()));
        
        return mn.modificarRescatista(newResc);
    }
    
    boolean registrarRescatista()
    {
        ManejoDB mn = new ManejoDB();
        Rescatista newResc = new Rescatista(this.txtNombre.getText(), this.txtApPat.getText(), this.txtApMat.getText(), Integer.parseInt(this.txtTel.getText()));
        
        return mn.agregarResc(newResc);
    }
    
    boolean eliminarRescatista()
    {
        ManejoDB mn = new ManejoDB();
        
        return mn.eliminar("rescatista", Integer.parseInt(this.txtId.getText()));
    }
    
    @FXML
    void isFieldActive()
    {
        String accion = this.cmbAcciones.getValue();
        
        if(accion.equalsIgnoreCase("Buscar"))
        {
            camposNoEditables();
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Modificar"))
            camposEditables();
        else if(accion.equalsIgnoreCase("Registrar"))
        {
            camposEditables();
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Eliminar"))
        {
            camposNoEditables();
            limpiarCajasTexto();
        }
    }
    
    @FXML
    void realizarAccion(ActionEvent e)
    {
        String accion = this.cmbAcciones.getValue();
        
        System.out.println("Se ha seleccionado: "+ accion.toUpperCase());
        
        if(accion.equalsIgnoreCase("Buscar"))
            buscarRescatista();
        else if(accion.equalsIgnoreCase("Modificar"))
        {
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea modificar rescatista?"))
            {
                if(!modificarRescatista())
                    UtilitiesViews.infoMensaje("EXITO", "Rescatista modificado con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Registrar"))
        {
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea registrar rescatista?"))
            {
                if(!registrarRescatista())
                    UtilitiesViews.infoMensaje("EXITO", "Rescatista registrado con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
        else if(accion.equalsIgnoreCase("Eliminar"))
        {   
            buscarRescatista();
            
            if(UtilitiesViews.confirmMensaje("Confirmación", "¿Seguro que desea eliminar rescatista?"))
            {
                if(!eliminarRescatista())
                    UtilitiesViews.infoMensaje("EXITO", "Rescatista eliminado con éxito");
                else
                    UtilitiesViews.infoMensaje("Ups", "Algo salió mal");
            }
            
            limpiarCajasTexto();
        }
    }
    
    void inicializarForm()
    {
        //inicializamos el comboBox
        this.cmbAcciones.getItems().addAll("Buscar", "Modificar", "Registrar", "Eliminar");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializarForm();
    }
}
