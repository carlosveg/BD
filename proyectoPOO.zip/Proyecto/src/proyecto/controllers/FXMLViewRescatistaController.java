package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import proyecto.models.Rescatista;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewRescatistaController implements Initializable {

    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApPat;
    @FXML
    private TextField txtApMat;
    @FXML
    private TextField txtTel;
    
    @FXML
    void volverOpciones(ActionEvent e) throws IOException
    {
        new UtilitiesViews().cambiarVentana("FXMLViewOptionsAdmin", "Bienvenido", e);
    }
    
    @FXML
    void busquedaRescatista(ActionEvent e)
    {
        ManejoDB mn = new ManejoDB();
        Rescatista searchResc = mn.obtenerRescatista(Integer.parseInt(this.txtId.getText()));
        
        if(searchResc != null)
        {
            this.txtNombre.setText(searchResc.getNombre());
            this.txtApPat.setText(searchResc.getApPat());
            this.txtApMat.setText(searchResc.getApMat());
            this.txtTel.setText(String.valueOf(searchResc.getTel()));
        }
        else
            UtilitiesViews.infoMensaje("Sin resultados", "No existe el rescatista con ID = "+ this.txtId.getText());
    }
    
    void inicializarForm()
    {
        this.txtId.setText("");
        this.txtNombre.setText("");
        this.txtApPat.setText("");
        this.txtApMat.setText("");
        this.txtTel.setText("");
        
        //desactivamos los TextField excepto el del ID para poder hacer búsquedas mediante el ID
        this.txtNombre.setEditable(false);
        this.txtApPat.setEditable(false);
        this.txtApMat.setEditable(false);
        this.txtTel.setEditable(false);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializarForm();
    }
}
