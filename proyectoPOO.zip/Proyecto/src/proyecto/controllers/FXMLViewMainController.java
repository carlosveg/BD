package proyecto.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewMainController implements Initializable {

    @FXML
    private TextField txtUser;
    @FXML
    private PasswordField txtPass;
    @FXML
    private Label lblUser;
    @FXML
    private Button btnIngresar;
    @FXML
    private Button btnRegistrar;
        
    private boolean todoOK;
    
    @FXML
    void iniciarRegistro(ActionEvent e) throws IOException
    {
        UtilitiesViews cambio = new UtilitiesViews();
        cambio.cambiarVentana("FXMLViewRegistro", "Registro", e);
    }
    
    boolean camposVacios()
    {
        this.todoOK = false;
        
        if(this.txtUser.getText().isEmpty() || this.txtPass.getText().isEmpty())
            this.todoOK = true;
        
        return this.todoOK;
    }
    
    @FXML
    void ingresoAdmin(ActionEvent e) throws IOException
    {
        if(!camposVacios())
        {
            ManejoDB mn = new ManejoDB();
            String user = this.txtUser.getText();
            String pass = this.txtPass.getText();

            System.out.println("USUARIO: "+ user);
            System.out.println("CONTARSEÑA: "+ pass);
            
            if(mn.loginAdmin(user, pass))
            {
                UtilitiesViews.infoMensaje("EXITO", "Login correcto");
                new UtilitiesViews().cambiarVentana("FXMLViewOptionsAdmin", "Bienvenido", e);
            }
            else
                UtilitiesViews.infoMensaje("ERROR", "Campos 'usuario' y/o 'contraseña' incorrectos");
        }
        else
            UtilitiesViews.infoMensaje("ERROR", "Debe llenar todos los campos");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }
}