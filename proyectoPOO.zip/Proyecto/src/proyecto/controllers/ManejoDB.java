package proyecto.controllers;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import proyecto.models.Administrador;
import proyecto.models.Rescatista;
import proyecto.models.Descripcion;
import proyecto.models.Mascota;
import proyecto.models.Tipo;

/**
 *
 * @author tans_
 */
public class ManejoDB {
    private ResultSet rs;
    private boolean todoOK;
    
    /* Inicia bloque de métodos para agregar */
    
    public boolean agregarAdmin(Administrador admin)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call admin_add(?,?,?,?,?,?)");
            
            cs.setString(1, admin.getNombre());
            cs.setString(2, admin.getApPat());
            cs.setString(3, admin.getApMat());
            cs.setInt(4, admin.getTel());
            cs.setString(5, admin.getUser());
            cs.setString(6, admin.getPass());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean agregarResc(Rescatista resc)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call rescatista_add(?,?,?,?)");
            
            cs.setString(1, resc.getNombre());
            cs.setString(2, resc.getApPat());
            cs.setString(3, resc.getApMat());
            cs.setInt(4, resc.getTel());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean agregarTipo(Tipo tipo)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call tipo_add(?, ?)");
            
            cs.setString(1, String.valueOf(tipo.getTipo()));
            cs.setString(2, tipo.getRaza());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean agregarDescripcion(Descripcion desc)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call descripcion_add(?,?,?,?,?,?,?)");
            
            cs.setInt(1, desc.getIdTipo());
            cs.setString(2, desc.getHistoria());
            cs.setInt(3, desc.getEdad());
            cs.setString(4, desc.getColor());
            cs.setString(5, String.valueOf(desc.getSexo()));
            cs.setString(6, String.valueOf(desc.getVacuna()));
            cs.setString(7, desc.getUrlImagen());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean agregarMascota(Mascota mascota)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call mascota_add(?,?,?)");
            
            cs.setInt(1, mascota.getIdResc());
            cs.setInt(2, mascota.getIdDesc());
            cs.setString(3, mascota.getNombre());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    /* Termina bloque de métodos para agregar */
    /* Inicia bloque de métodos para eliminar */
    
    /* Método genérico para eliminar 'x' modelo */
    public boolean eliminar(String eliminar, int id)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call "+ eliminar + "_delete(?)");
            
            cs.setInt(1, id);
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    /* Termina bloque de métodos para eliminar */
    /* Inicia bloque de métodos para modificar */
    
    public boolean modificarAdmin(Administrador nuevoAdmin)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call admin_update(?,?,?,?,?,?,?)");
            
            cs.setInt(1, nuevoAdmin.getId());
            cs.setString(2, nuevoAdmin.getNombre());
            cs.setString(3, nuevoAdmin.getApPat());
            cs.setString(4, nuevoAdmin.getApMat());
            cs.setInt(5, nuevoAdmin.getTel());
            cs.setString(6, nuevoAdmin.getUser());
            cs.setString(7, nuevoAdmin.getPass());
            
            if(cs.execute())
                this.todoOK = true;
            
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean modificarRescatista(Rescatista nuevoResc)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call rescatista_update(?,?,?,?,?)");
            
            cs.setInt(1, nuevoResc.getId());
            cs.setString(2, nuevoResc.getNombre());
            cs.setString(3, nuevoResc.getApPat());
            cs.setString(4, nuevoResc.getApMat());
            cs.setInt(5, nuevoResc.getTel());

            if(cs.execute())
                this.todoOK = true;
            
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean modificarTipo(Tipo tipo)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call tipo_update(?,?,?)");
            
            cs.setInt(1, tipo.getId());
            cs.setString(2, tipo.getTipo());
            cs.setString(3, tipo.getRaza());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean modificarDescripcion(Descripcion desc)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call descripcion_update(?,?,?,?,?,?,?,?)");
            
            cs.setInt(1, desc.getId());
            cs.setInt(2, desc.getIdTipo());
            cs.setString(3, desc.getHistoria());
            cs.setInt(4, desc.getEdad());
            cs.setString(5, desc.getColor());
            cs.setString(6, desc.getSexo());
            cs.setString(7, desc.getVacuna());
            cs.setString(8, desc.getUrlImagen());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    public boolean modificarMascota(Mascota mascota)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            CallableStatement cs = cn.prepareCall("call mascota_update(?,?,?,?)");
            
            cs.setInt(1, mascota.getId());
            cs.setInt(2, mascota.getIdResc());
            cs.setInt(3, mascota.getIdDesc());
            cs.setString(4, mascota.getNombre());
            
            if(cs.execute())
                this.todoOK = true;
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    /* Termina bloque de métodos para modificar */
    
    public boolean loginAdmin(String user, String pass)
    {
        this.todoOK = false;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select * from administrador where Usuario = ? and Contraseña = ?");
            
            ps.setString(1, user);
            ps.setString(2, pass);
            
            if(ps.execute())
            {
                ResultSet rs = ps.getResultSet();
                
                if(rs.next() && rs != null) //if(!rs.absolute(1))
                    this.todoOK = true;
            }
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return this.todoOK;
    }
    
    /* Bloque para controladores de administracion de mascotas y rescatistas */
    
    public Rescatista getRescatista(int id)
    {
        Rescatista rescObtenido = null;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select * from rescatista where IDRESC = ?");
            
            ps.setInt(1, id);
            
            this.rs = ps.executeQuery();
            
            if(this.rs.next())
            {
                rescObtenido = new Rescatista(rs.getString("Nombre"), rs.getString("ApPat"), rs.getString("ApMat"), rs.getInt("Telefono"));
                rescObtenido.setId(rs.getInt("IDRESC"));
            }
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return rescObtenido;
    }
    
    /* Bloque de métodos getter para obtener la descripción completa de la mascota */
    public Mascota getMascota(int id)
    {
        Mascota mascota = null;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select * from mascota where IDMASCOTA = ?");
            
            ps.setInt(1, id);
            
            this.rs = ps.executeQuery();
            
            if(this.rs.next())
            {
                mascota = new Mascota(rs.getInt("IDRESCATISTA"), rs.getInt("IDDESC"), rs.getString("Nombre"));
                mascota.setId(rs.getInt("IDMASCOTA"));
            }
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return mascota;
    }
    
    public Descripcion getDescripcion(int id)
    {
        Descripcion desc = null;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select * from descripcion where IDDESCRIPCION = ?");
            
            ps.setInt(1, id);
            
            this.rs = ps.executeQuery();
            
            if(this.rs.next())
            {
                desc = new Descripcion(rs.getInt("TIPOANIMAL"), rs.getString("Historia"), rs.getInt("Edad"), rs.getString("Color"), rs.getString("Sexo"), rs.getString("Vacuna"), rs.getString("urlImagen"));
                desc.setId(id);
            }
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return desc;
    }
    
    public Tipo getTipo(int id)
    {
        Tipo tipo = null;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select * from tipo where IDTIPO = ?");
            
            ps.setInt(1, id);
            
            this.rs = ps.executeQuery();
            
            if(this.rs.next())
            {
                tipo = new Tipo(rs.getString("Tipo"), rs.getString("Raza"));
                tipo.setId(id);
            }
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return tipo;
    }
    
    public int getLastId(String columna, String tabla)
    {
        int lastId = 0;
        
        try
        {
            Conexion conexion = new Conexion();
            Connection cn = conexion.getConexion();
            PreparedStatement ps = cn.prepareStatement("select MAX("+ columna +") as id from "+ tabla);
            
            this.rs = ps.executeQuery();
            
            if(this.rs.next())
                lastId = rs.getInt("id");
            
        }catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return lastId;
    }
    
}