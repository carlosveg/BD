package proyecto.controllers;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author tans_
 */
public class Conexion {
    private String host = "jdbc:mysql://localhost:3306/proyecto"; //host + nameBD
    private String user = "root";
    private String pass = "root";
    private String driver = "com.mysql.jdbc.Driver";
    private Connection conexion;

    public Conexion()
    {
        try
        {
            Class.forName(driver); //cargamos el driver
            conexion = DriverManager.getConnection(host, user, pass); //obtenemos la conexión
            System.out.println("Conexión exitosa"); //mensaje de prueba
            
            // bloque de prueba de conexión
            /*
            Statement st = conexion.createStatement();
            
            if(st.execute("show tables"))
            {
                String resultados = "";
                ResultSet rs = st.getResultSet();
                
                while(rs.next())
                    resultados += rs.getString(1) + "\n";
                
                System.out.println("\n"+ resultados);
            }
            conexion.close();
            */
        }catch(ClassNotFoundException | SQLException e){ //dos excepciones en un mismo catch
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
    public Connection getConexion()
    {
        return conexion;
    }
    
    public void cerrarConexion()
    {
        try
        {
            this.conexion.close();
            System.out.println("Conexión terminada");
        } catch (Exception e) {
        }
    }
}
