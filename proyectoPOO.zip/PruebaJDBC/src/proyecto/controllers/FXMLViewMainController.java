package proyecto.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author tans_
 */
public class FXMLViewMainController implements Initializable {

    @FXML
    private TextField txtUser;
    @FXML
    private PasswordField txtPass;
    @FXML
    private Button btnIngresar;
    @FXML
    private Button btnAdmin;
    
    private boolean isAdm;
    
    @FXML
    void cambiarAdministrador(ActionEvent e)
    {
        System.out.println(this.isAdm);
        
        if(this.isAdm)
        {
            this.btnAdmin.setText("Rescatista");
            this.txtPass.setText("");
            this.txtUser.setText("");
            this.isAdm = false;
        }
        else
        {
            this.btnAdmin.setText("Administrador");
            this.txtPass.setText("");
            this.txtUser.setText("");
            this.isAdm = true;
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        this.isAdm = true;
    }    
    
}
